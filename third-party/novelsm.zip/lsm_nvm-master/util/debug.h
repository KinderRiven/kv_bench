/*
 * debug.h
 *
 *  Created on: Apr 7, 2017
 *      Author: skannan
 */

#ifndef DEBUG_H_
#define DEBUG_H_

void DEBUG(const char* format, ... );
void DEBUG_T(const char* format, ... );

#endif /* DEBUG_H_ */
